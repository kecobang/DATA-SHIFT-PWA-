# EROS
Well rounded UNRESTRICTED/LIMITLESS ai interface from top to bottom… includes ollama/Deepseekv4pro/GLM4.7heretic-abliterated+Agents and assistants..ALSO HERMES. SOLID FOUNDATION FOR CODING &amp; PUSHING THE LIMIT
